import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'equaldiscstrips3.dart';

/// xSplits list of double between 0 and 100
class DiscStrip03CustomPainter extends CustomPainter {
  final List<double> xSplits; // = [11, 30, 42, 75];
  //  final List<double> xSplits = [11, 30, 42, 75];
  static const List<Color> defautlColors = [
    Colors.blue,
    Colors.red,
    Colors.green,
    Colors.grey,
    Colors.yellow,
  ];
  final List<Color> _colors;
  final double angle;

  final GlobalKey globalKey; // = 2.0;

  /// paints a disc with vertical colored strips starting at xSplits proportion.  angle is experimental.
  ///
  /// xSplits are increasing double between 0 and 1 and represent the proportion of the width of the disc
  /// Colors is determined by looping over the _colors List (which is optional).
  /// shouldRepaint has been optimized
  const DiscStrip03CustomPainter(
      {super.repaint,
      required this.xSplits,
      required this.angle,
      List<Color>? colorsP,
      required GlobalKey<State<StatefulWidget>> this.globalKey})
      : _colors = colorsP == null ? defautlColors : colorsP;
  @override
  void paint(Canvas canvas, Size size) {
    final renderObject = globalKey.currentContext?.findRenderObject();
    if (renderObject == null) {
      print('renderObject : nul');
    }
    print('renderObject : not nul !');
    final renderBox = renderObject as RenderBox;
    final Size renderBoxSize = renderBox.size;
    print('renderBoxSize: $renderBoxSize');
    /*    
 */
    // print('xSplits: $xSplits');
    //TODO implement non experimental rotate

    var center = size / 2;
    print('size: $size');
    // final Offset   offset = renderBox.localToGlobal(Offset.zero);

    /*   canvas.drawPath(
        Path()
          ..addOval(Rect.fromCenter(
              center: Offset(center.width, center.height),
              width: 20,
              height: 20)),
        Paint()..color = Colors.black); */

    canvas.save();
    canvas.translate(center.width, center.height);

    canvas.rotate(angle);

    canvas.translate(-center.width, -center.height);

    const minSize = 50.0;
    // final double dim = size.height < minSize ? minSize : size.height;
    final double dim = size.width < minSize ? minSize : size.width;
    int colorIndex = _colors.length - 1;
    double left = -1;
    double right = 0;
    var paint = Paint();
    bool parity = true;
    for (var xCoord in xSplits) {
      left = right;
      right = xCoord * dim;
      colorIndex = colorIndex == _colors.length - 1 ? 0 : colorIndex + 1;

      final Color color = _colors[colorIndex];
      paintStrip(canvas, paint, size, left, right, color, dim);
    }
    for (var xCoord in xSplits) {
      left = right;
      right = xCoord * dim;
      colorIndex = colorIndex == _colors.length - 1 ? 0 : colorIndex + 1;

      final Color color = _colors[colorIndex];
      paintText(canvas, paint, size, left, right, xCoord, color, dim, parity);
      parity = !parity;
    }
    canvas.restore();

/* 
    // this Path shows the center of the canvas which will be the rotating point

    canvas.drawPath(
        Path()
          ..addOval(Rect.fromCenter(
              center: Offset(center.width, center.height),
              width: 20,
              height: 20)),
        Paint()..color = Colors.black);
    canvas.drawPath(
        Path()
          ..addRect(Rect.fromCenter(
              center: Offset(center.width, center.height),
              width: size.width,
              height: size.height)),
        Paint()
          ..color = Colors.black
          ..style = PaintingStyle.stroke);
 */
    print('DiscStrip02CustomPainter called');
  }

  @override
  bool shouldRepaint(DiscStrip03CustomPainter oldDelegate) {
    if (angle != oldDelegate.angle) {
      print('repainted: shouldRepaint = true');
      return true;
    }
    if (_colors != oldDelegate._colors) {
      print('repainted: shouldRepaint = true');
      return true;
    }
    if (xSplits != oldDelegate.xSplits) {
      print('repainted: shouldRepaint = true');
      return true;
    }
    //TODO optimize
    print('repainted: shouldRepaint = false');
    return false;
  }
}

/// change paint with color and draw a disc strip on canvas.
void paintStrip(Canvas canvas, Paint paint, Size size, double left,
    double right, Color color, double dim) {
  final double top = 0;
  final smallestDimension =
      dim; // 100.0; //      size.height < size.width ? size.height : size.height;
  final double bottom = smallestDimension; // size.height;
  // final double rectRight = size.width;
  final double rectRight = bottom;
  paint = paint..color = color;
  var pathCombine = Path.combine(
    PathOperation.intersect,
    Path()..addRect(Rect.fromLTRB(left, top, right, smallestDimension)),
    Path()
      ..addOval(Rect.fromLTRB(top, 0, smallestDimension, smallestDimension)),
    /*    Path()..addRect(Rect.fromLTRB(left, top, right, bottom)),
    Path()..addOval(Rect.fromLTRB(top, 0, rectRight, bottom)), */
  );

  // print('left: $left');

  canvas.drawPath(pathCombine, paint);
}

void paintText(Canvas canvas, Paint paint, Size size, double left, double right,
    double xCoord, Color color, double dim, bool parity) {
  const double upToText = 7;
  final smallestDimension = dim;
  final double bottom = smallestDimension;
  final double rectRight = bottom;
  paint = paint..color = color;
  var center = size / 2;
  var style = TextStyle(color: Colors.black);

  final double xCos = cosEquivFrom(xCoord);

  final ui.ParagraphBuilder paragraphBuilder =
      ui.ParagraphBuilder(ui.ParagraphStyle(
    fontSize: style.fontSize,
    fontFamily: style.fontFamily,
    fontStyle: style.fontStyle,
    fontWeight: style.fontWeight,
    textAlign: TextAlign.justify,
  ))
        ..pushStyle(style.getTextStyle())
        ..addText('${xCos.toStringAsFixed(2)}');
  final ui.Paragraph paragraph = paragraphBuilder.build()
    ..layout(ui.ParagraphConstraints(width: size.width));
  canvas.drawParagraph(
      paragraph,
      Offset(
          right - 12, smallestDimension / 2 + (parity ? upToText : -upToText)));
  // canvas.drawParagraph(paragraph, Offset(0, 0));
}

double cosEquivFrom(double x0FromLeft) {
  return 2 * x0FromLeft - 1;
}

List<double> getProportionnalXWithOneFrom(List<DiscSliceResultPart> parts) {
  // final List<DiscSliceResultPart> parts = getDiscSliceResultOf(_counter);
  //  print('_counter: $_counter');
  //  print('parts: $parts');
  final List<double> xSplitsParts = parts.map((e) => e.xResult).toList();
  // print('xSplitsParts: $xSplitsParts');
  final List<double> xSplitsRes = xSplitsParts.map((e) => (e + 1) / 2).toList();
  xSplitsRes.add(1.0);
  //  print('xSplitsRes: $xSplitsRes');
  return xSplitsRes;
}
