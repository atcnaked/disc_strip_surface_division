import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class CombineCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var center = size / 2;
    var paint = Paint()
      ..color = Colors.black
      ..strokeWidth = 3.0;
    final center1Offset = Offset(center.height, center.height);
    final center2Offset = Offset(center.height + 20, center.height + 20);
    //  final center2Offset= center1Offset/2;//    Offset(size.width, center.height+20);
    var pathCombine = Path.combine(
      PathOperation.difference,
      Path()
        ..addRect(Rect.fromCenter(
          center: center2Offset,
          width: 50,
          height: 50,
        )),
      Path()
        ..addRect(Rect.fromCenter(
          center: center1Offset,
          width: 50,
          height: 50,
        )),
    );
    /*  Path()
        ..addOval(Rect.fromCenter(
            center: Offset(0, notch.dy + 10), width: 20, height: 20))
        ..addOval(Rect.fromCenter(
            center: Offset(size.width, notch.dy + 10), width: 20, height: 20)), */

    canvas.drawPath(pathCombine, paint);

    paint = paint..color = Colors.red;

    var point2 = size / 10;

    final center3Offset = Offset(point2.height, point2.height);
    final center4Offset = Offset(point2.height + 20, point2.height + 20);
    var pathCombine2 = Path.combine(
      PathOperation.xor,
      Path()
        ..addRect(Rect.fromCenter(
          center: center3Offset,
          width: 50,
          height: 50,
        )),
      Path()
        ..addRect(Rect.fromCenter(
          center: center4Offset,
          width: 50,
          height: 50,
        )),
    );

    canvas.drawPath(pathCombine2, paint);
    canvas.drawCircle(Offset(0, center.height), 10.0, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class Combine2CustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final double stripWidth = 20;
  
    final double left = 21;
    final double top = 0;
    final double right = left + stripWidth;
    final double bottom = size.height;
      var paint = Paint()
      ..color = Colors.red
      ..strokeWidth = 3.0;
    var pathCombine = Path.combine(
      PathOperation.intersect,
      Path()..addRect(Rect.fromLTRB(left, top, right, bottom)),
      Path()..addOval(Rect.fromLTRB(top, 0, 100, bottom)),
    );

    final double left2 = right;
    final double right2 =  left2 + stripWidth;
    canvas.drawPath(pathCombine, paint);
    paint = paint..color = Colors.green;
      var pathCombine2 = Path.combine(
      PathOperation.intersect,
      Path()..addRect(Rect.fromLTRB(left2, top, right2, bottom)),
      Path()..addOval(Rect.fromLTRB(top, 0, 100, bottom)),
    );
    canvas.drawPath(pathCombine2, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
