import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class MultiLinesCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var center = size / 2;
    var paint = Paint()
      ..color = Colors.yellow
      ..strokeWidth = 20.0;

    var path = Path()
      ..moveTo(0, 0)
      ..lineTo(100, 100)
      ..lineTo(0, 100)
      ..lineTo(0, 0);

    canvas.drawPath(path, paint);

    paint = paint..color = Colors.red;

    canvas.drawCircle(Offset(0, center.height), 10.0, paint);

    paint = paint..color = Colors.green;

    final div2OffsetTest=Offset(size.width, center.height)/2;

    canvas.drawLine(        Offset(0, center.height), Offset(size.width, center.height), paint);
    paint = paint..color = Colors.greenAccent;
    canvas.drawLine(        Offset(0, center.height), div2OffsetTest, paint);

    paint.color = Colors.blue;

    var rect = Rect.fromCenter(
      center: Offset(100, 100),
      width: 50,
      height: 80,
    );

    canvas.drawRect(rect, paint);
    var style = TextStyle(color: Colors.black);

    final ui.ParagraphBuilder paragraphBuilder =
        ui.ParagraphBuilder(ui.ParagraphStyle(
      fontSize: style.fontSize,
      fontFamily: style.fontFamily,
      fontStyle: style.fontStyle,
      fontWeight: style.fontWeight,
      textAlign: TextAlign.justify,
    ))
          ..pushStyle(style.getTextStyle())
          ..addText('Demo Text');
    final ui.Paragraph paragraph = paragraphBuilder.build()
      ..layout(ui.ParagraphConstraints(width: size.width));
    canvas.drawParagraph(paragraph, Offset(center.width, center.height+20));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class DrawColorCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var center = size / 2;
    var paint = Paint()
      ..color = Colors.yellow
      ..strokeWidth = 20.0;

    paint = paint..color = Colors.red;

    canvas.drawCircle(Offset(0, center.height), 10.0, paint);
    // cautions it acts on all the other widget ?!
    // canvas.drawColor(Colors.grey, BlendMode.color);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
