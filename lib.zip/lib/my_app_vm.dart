import 'dart:developer';

import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MyInnerWidget(viewModel: MyViewModel(),);
  }
}



class MyInnerWidget extends StatelessWidget {
  final MyViewModel viewModel;
  const MyInnerWidget({required this.viewModel ,super.key});

  @override
  Widget build(BuildContext context) {
    return Column(children: [

      Text('AAA'),
      AnimatedBuilder(animation: viewModel, builder: (context, child){
return Text('via AnimatedBuilder: ${viewModel.number}');

      }),
      ElevatedButton(onPressed: (){

        viewModel.addOne();


      }, child: Text('${viewModel.number}'))
    ],);
  }
}

class MyViewModel extends ChangeNotifier {
  int number = -1;

  void addOne(){
    number = number +1;
    log('addOne: $number');

    notifyListeners();
  }
  
}