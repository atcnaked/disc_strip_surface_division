import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class TestRotateDiscStrip05CustomPainter extends CustomPainter {
  final double angle;

  const TestRotateDiscStrip05CustomPainter({
    super.repaint,
    required this.angle,
  });
  @override
  void paint(Canvas canvas, Size size) {
    //TODO implement non experimental rotate

    final thePaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke;

    var center = size / 2;
    // final Offset   offset = renderBox.localToGlobal(Offset.zero);

    canvas.save();
    canvas.translate(center.width, center.height);
    print('center.width, center.height, ${center.width}, ${center.height}');
    // from what I understand rotate does not rotate the thing we draw on but change the way we draw
    // thus later only a restore is enough
    canvas.rotate(1);
    canvas.translate(-center.width, -center.height);

    canvas.drawPath(
        Path()
          ..addRect(Rect.fromCenter(
              center: Offset(center.width, center.height),
              width: size.width,
              height: size.height)),
        thePaint);
    canvas.restore();
    canvas.clipPath(
        Path()..addRect(Rect.fromLTWH(0, 0, size.width, size.height)));

    // this Path shows the center of the canvas which will be the rotating point
    canvas.drawPath(
        Path()
          ..addOval(Rect.fromCenter(
              center: Offset(center.width, center.height),
              width: 10,
              height: 10)),
        thePaint);
    // this Path shows the border of the canvas
    canvas.drawPath(
        Path()
          ..addRect(Rect.fromCenter(
              center: Offset(center.width, center.height),
              width: size.width,
              height: size.height)),
        thePaint);

    print('DiscStrip02CustomPainter called');
  }

  @override
  bool shouldRepaint(TestRotateDiscStrip05CustomPainter oldDelegate) {
    return true;
  }
}
