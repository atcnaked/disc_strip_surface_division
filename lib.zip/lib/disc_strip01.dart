import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class DiscStrip01CustomPainter extends CustomPainter {
      final List<double> xSplits = [11, 30, 42, 55];
    final List<Color> colors = [
      Colors.blue,
      Colors.red,
      Colors.green,
      Colors.black,
      Colors.yellow,
    ];
  @override
  void paint(Canvas canvas, Size size) {
 /*    final List<double> xSplits = [11, 30, 42, 55];
    final List<Color> colors = [
      Colors.blue,
      Colors.red,
      Colors.green,
      Colors.black,
      Colors.yellow,
    ]; */
    int colorIndex = colors.length;
    double left = -1;
    double right = 0;
    var paint = Paint();
    for (var xCoord in xSplits) {
      left = right;
      right = xCoord;
      colorIndex = colorIndex == colors.length ? 0 : colorIndex + 1;

      final Color color = colors[colorIndex];
      final res = paintStrip(canvas, paint, size, left, right, color);
      canvas = res.$1;
      paint = res.$2;
    }
  }

  void paintbak(Canvas canvas, Size size) {
    final double stripWidth = 20;

    final double left = 21;
    final double top = 0;
    final double right = left + stripWidth;
    final double bottom = size.height;
    var paint = Paint()
      ..color = Colors.red
      ..strokeWidth = 3.0;
    var pathCombine = Path.combine(
      PathOperation.intersect,
      Path()..addRect(Rect.fromLTRB(left, top, right, bottom)),
      Path()..addOval(Rect.fromLTRB(top, 0, 100, bottom)),
    );

    final double left2 = right;
    final double right2 = left2 + stripWidth;
    canvas.drawPath(pathCombine, paint);
    paint = paint..color = Colors.green;
    var pathCombine2 = Path.combine(
      PathOperation.intersect,
      Path()..addRect(Rect.fromLTRB(left2, top, right2, bottom)),
      Path()..addOval(Rect.fromLTRB(top, 0, 100, bottom)),
    );
    canvas.drawPath(pathCombine2, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

(Canvas, Paint) paintStrip(Canvas canvas, Paint paint, Size size, double left,
    double right, Color color) {
  final double top = 0;
  final double bottom = size.height;
  paint = paint..color = color;
  var pathCombine = Path.combine(
    PathOperation.intersect,
    Path()..addRect(Rect.fromLTRB(left, top, right, bottom)),
    Path()..addOval(Rect.fromLTRB(top, 0, 100, bottom)),
  );

  print('left: $left');

  canvas.drawPath(pathCombine, paint);
  return (canvas, paint);
}
